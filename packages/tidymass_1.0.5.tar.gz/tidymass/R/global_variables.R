globalVariables(names = c("package",
                          "up_to_date"))