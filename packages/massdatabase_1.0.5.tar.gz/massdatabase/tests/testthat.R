library(testthat)
library(massdatabase)

test_check("massdatabase")
