library(testthat)
library(masstools)

test_check("masstools")
