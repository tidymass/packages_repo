## ---- include = FALSE, echo=FALSE---------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  warning = FALSE,
  message = TRUE,
  out.width = "100%"
)

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
library(masstools)
library(tidyverse)

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
sum_formula(formula = "C9H11NO2", adduct = "M+H")
sum_formula(formula = "C9H11NO2", adduct = "M+")
sum_formula(formula = "C9H11NO2", adduct = "M+CH3COOH")
sum_formula(formula = "C9H11", adduct = "M-H20")

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
split_formula(formula = "C9H11NO2")
split_formula(formula = "C2H4")

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
###remove the noisy peaks in one ms2 spectrum
exp.spectrum <- data.frame(mz = c(1:10, 1.0001), 
                           intensity = c(1:10, 0.1))

ms2_plot(exp.spectrum)

exp.spectrum2 = removeNoise(exp.spectrum)

ms2_plot(exp.spectrum, exp.spectrum2)

###match two spectra according to mz
exp.spectrum <- data.frame(mz = 1:10, intensity = 1:10)
lib.spectrum <- data.frame(mz = 1:10, intensity = 1:10)
ms2Match(exp.spectrum, lib.spectrum)


## calculate the dot product of two matched intensity
getDP(exp.int = 1:10, lib.int = 1:10)
getDP(exp.int = 10:1, lib.int = 1:10)

###matched two spectra and calculate dot product
exp.spectrum <- data.frame(mz = 1:10, intensity = 1:10)
lib.spectrum <- data.frame(mz = 1:10, intensity = 1:10)
getSpectraMatchScore(exp.spectrum, lib.spectrum)

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
spectrum1 <- data.frame(
    mz = c(
        87.50874,
        94.85532,
        97.17808,
        97.25629,
        103.36186,
        106.96647,
        107.21461,
        111.00887,
        113.79269,
        118.70564
    ),
    intensity =
        c(
            8356.306,
            7654.128,
            9456.207,
            8837.188,
            8560.228,
            8746.359,
            8379.361,
            169741.797,
            7953.080,
            8378.066
        )
)
spectrum2 <- spectrum1
ms2_plot(spectrum1, spectrum2)
ms2_plot(spectrum1, spectrum2, interactive_plot = TRUE)
ms2_plot(spectrum1)
ms2_plot(spectrum1, interactive_plot = TRUE)

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
data1 <- data.frame(mz = 1:10, rt = 1:10)
data2 <- data.frame(mz = 1:10, rt = 1:10)
mz_rt_match(data1, data2, mz.tol = 10)

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
library(masstools)

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
database_name = trans_id_database(server = "cts.fiehnlab")

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
head(database_name$From$From)

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
head(database_name$To$From)

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
trans_ID(
  query = "C00001",
  from = "KEGG",
  to = "Human Metabolome Database",
  top = 1,
  server = "cts.fiehnlab"
)

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
c("C00001", "C00001", "C00001") %>%
  purrr::map(
    .f = function(x) {
      trans_ID(
        query = x,
        from = "KEGG",
        to = "Human Metabolome Database",
        top = 1,
        server = "cts.fiehnlab"
      )
    }
  ) %>%
  do.call(rbind, .) %>%
  as.data.frame()

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
database_name2 = trans_id_database(server = "chemspider")

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
database_name2$From

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
database_name2$To

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
trans_ID(
  query = "C00001",
  from = "KEGG",
  to = "ChemSpider",
  top = 1,
  server = "cts.fiehnlab"
)

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
trans_ID(
  query = "140526",
  from = "csid",
  to = "mol",
  top = 1,
  server = "chemspider"
)

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
result = 
get_compound_class(
  inchikey = "QZDWODWEESGPLC-UHFFFAOYSA-N",
  server = "http://classyfire.wishartlab.com/entities/",
  sleep = 5
)

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
result

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
name_duplicated(c("a", "a", "b", "c", "a", "b", "c", "a"))
name_duplicated(c(rep(1, 5), 2))
name_duplicated(1:5)

## ----eval=FALSE,warning=FALSE, R.options="", message=FALSE--------------------
#  ####just open the current working directory
#  openwd()
#  ###A new folder will be opened and pop up

## ----eval=FALSE,warning=FALSE, R.options="", message=FALSE--------------------
#  setwd_win()

## ----eval=FALSE,warning=FALSE, R.options="", message=FALSE--------------------
#  setwd_project()

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
get_os()

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
masstools_logo()

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
masstools_conflicts()

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
masstools_packages()

## ----eval=TRUE,warning=FALSE, R.options="", message=FALSE---------------------
sessionInfo()

