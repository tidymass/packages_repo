#' #' @silence.deprecated Silence deprecated information or not.
#' #' 
#' if(!silence.deprecated){
#' cat(crayon::yellow("`getData()` is deprecated, please use `get_data()`"))
#' }
