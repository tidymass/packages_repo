# Version 0.0.1 (20210210)

* Creation.

# Version 0.99.7 (20220322)

* Add a rmarkdown template.

# Version 1.0.1 (2022-08-06)

* Fix bugs.

# Version 1.0.2 (2022-09-01)

* Fix bugs.

# Version 1.0.3

* Add one more attached core package.

# Version 1.0.4 (2022-09-15)

* Fix bugs.

# Version 1.0.5 (2022-09-17)

* Fix one bug in update_tidymass.

# Version 1.0.6 (2022-09-19)

* Can update tidymass from fastgit.